from flask import Flask, render_template, request
import json
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/handle_data', methods=['POST'])
def handle_data():
    return json.dumps(request.form.to_dict(flat=False))